<?php
    	class Magmi_Version
    	{
    		 public static $version="0.7.18";
    	}